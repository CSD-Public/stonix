#!/usr/bin/python -u

import os
import sys
import getpass
from subprocess import Popen, PIPE

username = raw_input("Username: ")
passwd = getpass.getpass("Password: ")
print username
print passwd

cmdOne = ["/usr/bin/su", username.strip()]
oneout = open('oneout', 'wb')
oneerr = open('oneerr', 'wb')

onePipe = Popen(cmdOne, stdout=PIPE, stderr=PIPE, stdin=PIPE, shell=True, bufsize=0).communicate(input='Lindse4%tirling\n')
print onePipe

#onePipe.stdout.readline()

#onePipe.stdout.flush()
#onePipe.stdin.write(passwd + "\n")

#onePipe.wait()

    
