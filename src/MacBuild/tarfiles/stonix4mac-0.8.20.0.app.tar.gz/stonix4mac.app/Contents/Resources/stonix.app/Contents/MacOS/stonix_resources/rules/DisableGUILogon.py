###############################################################################
#                                                                             #
# Copyright 2015.  Los Alamos National Security, LLC. This material was       #
# produced under U.S. Government contract DE-AC52-06NA25396 for Los Alamos    #
# National Laboratory (LANL), which is operated by Los Alamos National        #
# Security, LLC for the U.S. Department of Energy. The U.S. Government has    #
# rights to use, reproduce, and distribute this software.  NEITHER THE        #
# GOVERNMENT NOR LOS ALAMOS NATIONAL SECURITY, LLC MAKES ANY WARRANTY,        #
# EXPRESS OR IMPLIED, OR ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  #
# If software is modified to produce derivative works, such modified software #
# should be clearly marked, so as not to confuse it with the version          #
# available from LANL.                                                        #
#                                                                             #
# Additionally, this program is free software; you can redistribute it and/or #
# modify it under the terms of the GNU General Public License as published by #
# the Free Software Foundation; either version 2 of the License, or (at your  #
# option) any later version. Accordingly, this program is distributed in the  #
# hope that it will be useful, but WITHOUT ANY WARRANTY; without even the     #
# implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    #
# See the GNU General Public License for more details.                        #
#                                                                             #
###############################################################################
'''
Created on 2015/07/01

@author: Eric Ball
'''
from __future__ import absolute_import

import os
import re
import traceback
from ..KVEditorStonix import KVEditorStonix
from ..logdispatcher import LogPriority
from ..pkghelper import Pkghelper
from ..rule import Rule
from ..CommandHelper import CommandHelper
from ..ServiceHelper import ServiceHelper
from ..stonixutilityfunctions import iterate, readFile, writeFile, createFile
from ..stonixutilityfunctions import resetsecon


class DisableGUILogon(Rule):

    def __init__(self, config, environ, logger, statechglogger):
        Rule.__init__(self, config, environ, logger, statechglogger)
        self.logger = logger
        self.rulenumber = 105
        self.rulename = "DisableGUILogon"
        self.formatDetailedResults("initialize")
        self.mandatory = False
        self.helptext = '''This rule will disable, secure, or entirely remove \
the X11/X Windows GUI.'''
        self.applicable = {'type': 'white',
                           'family': ['linux']}

        # Configuration item instantiation
        datatype = "bool"
        key = "DISABLEX"
        instructions = "To enable this item, set the value of DISABLEX " + \
        "to True. When enabled, this rule will disable the automatic " + \
        "GUI login, and the system will instead boot to the console " + \
        "(runlevel 3). This will not remove any GUI components, and the " + \
        "GUI can still be started using the \"startx\" command."
        default = False
        self.ci1 = self.initCi(datatype, key, instructions, default)

        datatype = "bool"
        key = "LOCKDOWNX"
        instructions = "To enable this item, set the value of LOCKDOWNX " + \
        "to True. When enabled, this item will help secure X Windows by " + \
        "disabling the X Font Server (xfs) service and disabling X " + \
        "Window System Listening. This item should be enabled if X " + \
        "Windows is disabled but will be occasionally started via " + \
        "startx, unless there is a mission-critical need for xfs or " + \
        "a remote display."
        default = False
        self.ci2 = self.initCi(datatype, key, instructions, default)

        datatype = "bool"
        key = "REMOVEX"
        instructions = "To enable this item, set the value of REMOVEX " + \
        "to True. When enabled, this item will COMPLETELY remove X Windows " + \
        "from the system, and on most platforms will disable any currently " + \
        "running display manager. It is therefore recommended that this " + \
        "rule be run from a console session rather than from the GUI.\n" + \
        "REMOVEX cannot be undone."
        default = False
        self.ci3 = self.initCi(datatype, key, instructions, default)

        self.guidance = ["NSA 3.6.1.1", "NSA 3.6.1.2", "NSA 3.6.1.3",
                         "CCE 4462-8", "CCE 4422-2", "CCE 4448-7", "CCE 4074-1"]
        self.iditerator = 0
        self.created = False

    def report(self):
        '''
        @author: Eric Ball
        @param self - essential if you override this definition
        @return: bool - True if system is compliant, False if it isn't
        '''
        try:
            self.ph = Pkghelper(self.logger, self.environ)
            self.ch = CommandHelper(self.logger)
            self.sh = ServiceHelper(self.environ, self.logger)
            self.myos = self.environ.getostype().lower()
            compliant = True
            results = ""

            if os.path.exists("/bin/systemctl"):
                self.initver = "systemd"
                compliant, results = self.reportSystemd()
            elif re.search("debian", self.myos):
                self.initver = "debian"
                compliant, results = self.reportDebian()
            elif re.search("ubuntu", self.myos):
                self.initver = "ubuntu"
                compliant, results = self.reportUbuntu()
            else:
                self.initver = "inittab"
                compliant, results = self.reportInittab()

            # NSA guidance specifies disabling of X Font Server (xfs),
            # however, this guidance seems to be obsolete as of RHEL 6,
            # and does not apply to the Debian family.
            if self.sh.auditservice("xfs"):
                compliant = False
                results += "xfs is currently enabled\n"

            xremoved = True
            if re.search("debian|ubuntu", self.myos):
                if self.ph.check("xserver-xorg-core"):
                    compliant = False
                    xremoved = False
                    results += "Core X11 components are present\n"
            elif re.search("opensuse", self.myos):
                if self.ph.check("xorg-x11-server"):
                    compliant = False
                    xremoved = False
                    results += "Core X11 components are present\n"
            else:
                if self.ph.check("xorg-x11-server-Xorg"):
                    compliant = False
                    xremoved = False
                    results += "Core X11 components are present\n"
            # Removing X will take xserverrc with it. If X is not present, we
            # do not need to check for xserverrc
            if not xremoved:
                self.serverrc = "/etc/X11/xinit/xserverrc"
                self.xservSecure = False
                if os.path.exists(self.serverrc):
                    serverrcText = readFile(self.serverrc, self.logger)
                    if re.search("opensuse", self.myos):
                        for line in serverrcText:
                            reSearch = r'exec (/usr/bin/)?X \$dspnum.*\$args'
                            if re.search(reSearch, line):
                                self.xservSecure = True
                                break
                    else:
                        for line in serverrcText:
                            reSearch = r'^exec (/usr/bin/)?X (:0 )?-nolisten tcp ("$@"|.?\$@)'
                            if re.search(reSearch, line):
                                self.xservSecure = True
                                break
                    if not self.xservSecure:
                        compliant = False
                        results += self.serverrc + " does not contain proper " \
                                   + "settings to disable X Window System " + \
                                   "Listening/remote display\n"
                else:
                    compliant = False
                    results += self.serverrc + " does not exist; X Window " + \
                               "System Listening/remote display has not " + \
                               "been disabled\n"

            self.compliant = compliant
            if self.compliant:
                self.detailedresults = "DisableGUILogon report has been " + \
                                       "run and is compliant"
            else:
                self.detailedresults = "DisableGUILogon report has been " + \
                                       "run and is not compliant\n" + results
        except (KeyboardInterrupt, SystemExit):
            raise
        except Exception:
            self.rulesuccess = False
            self.detailedresults = "\n" + traceback.format_exc()
            self.logger.log(LogPriority.ERROR, self.detailedresults)
        self.formatDetailedResults("report", self.compliant,
                                   self.detailedresults)
        self.logger.log(LogPriority.INFO, self.detailedresults)
        return self.compliant

    def reportInittab(self):
        compliant = False
        results = ""
        inittab = "/etc/inittab"
        if os.path.exists(inittab):
            initData = readFile(inittab, self.logger)
            for line in initData:
                if line.strip() == "id:3:initdefault:":
                    compliant = True
                    break
        else:
            self.logger.log(LogPriority.ERROR, inittab + " not found, init " +
                            "system unknown")
        if not compliant:
            results = "inittab not set to runlevel 3; GUI logon is enabled\n"
        return compliant, results

    def reportSystemd(self):
        compliant = True
        results = ""
        cmd = ["/bin/systemctl", "get-default"]
        self.ch.executeCommand(cmd)
        defaultTarget = self.ch.getOutputString()
        if not re.search("multi-user.target", defaultTarget):
            compliant = False
            results = "systemd default target is not multi-user.target; " + \
                      "GUI logon is enabled\n"
        return compliant, results

    def reportDebian(self):
        compliant = True
        results = ""
        dmlist = ["gdm", "gdm3", "lightdm", "xdm", "kdm"]
        for dm in dmlist:
            if self.sh.auditservice(dm):
                compliant = False
                results = dm + " is still in init folders; GUI logon is enabled\n"
        return compliant, results

    def reportUbuntu(self):
        compliant = True
        results = ""
        ldmover = "/etc/init/lightdm.override"
        grub = "/etc/default/grub"
        if os.path.exists(ldmover):
            lightdmText = readFile(ldmover, self.logger)
            if not "manual" in lightdmText:
                compliant = False
                results += ldmover + " exists, but does not contain text " + \
                           '"manual". GUI logon is still enabled\n'
        else:
            compliant = False
            results += ldmover + " does not exist; GUI logon is enabled\n"
        if os.path.exists(grub):
            tmppath = grub + ".tmp"
            data = {"GRUB_CMDLINE_LINUX_DEFAULT": '"quiet"'}
            editor = KVEditorStonix(self.statechglogger, self.logger, "conf",
                                    grub, tmppath, data, "present", "closedeq")
            if not editor.report():
                compliant = False
                results += grub + " does not contain the correct values: " + \
                           str(data)
        else:
            compliant = False
            results += "Cannot find file " + grub
        if not compliant:
            results = "/etc/init does not contain proper override file " + \
                      "for lightdm; GUI logon is enabled\n"
        return compliant, results

    def fix(self):
        '''
        @author: Eric Ball
        @param self - essential if you override this definition
        @return: bool - True if fix is successful, False if it isn't
        '''
        try:
            if not self.ci1.getcurrvalue() and not self.ci2.getcurrvalue() \
               and not self.ci3.getcurrvalue():
                return
            success = True
            results = ""
            # Delete past state change records from previous fix
            self.iditerator = 0
            eventlist = self.statechglogger.findrulechanges(self.rulenumber)
            for event in eventlist:
                self.statechglogger.deleteentry(event)

            if self.ci1.getcurrvalue() or self.ci3.getcurrvalue():
                if self.initver == "systemd":
                    cmd = ["/bin/systemctl", "set-default", "multi-user.target"]
                    if not self.ch.executeCommand(cmd):
                        success = False
                        results += '"systemctl set-default multi-user.target"' \
                                   + " did not succeed\n"
                    else:
                        self.iditerator += 1
                        myid = iterate(self.iditerator, self.rulenumber)
                        commandstring = "/bin/systemctl set-default " + \
                                        "graphical.target"
                        event = {"eventtype": "commandstring",
                                 "command": commandstring}
                        self.statechglogger.recordchgevent(myid, event)

                elif self.initver == "debian":
                    dmlist = ["gdm", "gdm3", "lightdm", "xdm", "kdm"]
                    for dm in dmlist:
                        if not self.sh.disableservice(dm):
                            results += "Failed to disable desktop " + \
                                       "manager " + dm
                        else:
                            self.iditerator += 1
                            myid = iterate(self.iditerator, self.rulenumber)
                            event = {"eventtype":   "servicehelper",
                                     "servicename": dm,
                                     "startstate":  "enabled",
                                     "endstate":    "disabled"}
                            self.statechglogger.recordchgevent(myid, event)

                elif self.initver == "ubuntu":
                    ldmover = "/etc/init/lightdm.override"
                    tmpfile = ldmover + ".tmp"
                    if not os.path.exists(ldmover):
                        createFile(ldmover, self.logger)
                        self.iditerator += 1
                        myid = iterate(self.iditerator, self.rulenumber)
                        event = {"eventtype": "creation", "filepath": ldmover}
                        self.statechglogger.recordchgevent(myid, event)
                    writeFile(tmpfile, "manual", self.logger)
                    self.iditerator += 1
                    myid = iterate(self.iditerator, self.rulenumber)
                    event = {"eventtype": "conf", "filepath": ldmover}
                    self.statechglogger.recordchgevent(myid, event)
                    self.statechglogger.recordfilechange(ldmover, tmpfile, myid)
                    os.rename(tmpfile, ldmover)
                    resetsecon(ldmover)

                    grub = "/etc/default/grub"
                    if not os.path.exists(grub):
                        createFile(grub, self.logger)
                        self.iditerator += 1
                        myid = iterate(self.iditerator, self.rulenumber)
                        event = {"eventtype": "creation", "filepath": grub}
                        self.statechglogger.recordchgevent(myid, event)
                    tmppath = grub + ".tmp"
                    data = {"GRUB_CMDLINE_LINUX_DEFAULT": '"quiet"'}
                    editor = KVEditorStonix(self.statechglogger, self.logger,
                                            "conf", grub, tmppath, data,
                                            "present", "closedeq")
                    editor.report()
                    if editor.fixables:
                        if editor.fix():
                            debug = "kveditor fix ran successfully\n"
                            self.logger.log(LogPriority.DEBUG, debug)
                            if editor.commit():
                                debug = "kveditor commit ran successfully\n"
                                self.logger.log(LogPriority.DEBUG, debug)
                            else:
                                error = "kveditor commit did not run " + \
                                        "successfully\n"
                                self.logger.log(LogPriority.ERROR, error)
                                success = False
                        else:
                            error = "kveditor fix did not run successfully\n"
                            self.logger.log(LogPriority.ERROR, error)
                            success = False
                    cmd = "update-grub"
                    self.ch.executeCommand(cmd)

                else:
                    inittab = "/etc/inittab"
                    tmpfile = inittab + ".tmp"
                    if os.path.exists(inittab):
                        initText = open(inittab, "r").read()
                        initre = r"id:\d:initdefault:"
                        if re.search(initre, initText):
                            initText = re.sub(initre, "id:3:initdefault:",
                                              initText)
                            writeFile(tmpfile, initText, self.logger)
                            self.iditerator += 1
                            myid = iterate(self.iditerator, self.rulenumber)
                            event = {"eventtype": "conf", "filepath": inittab}
                            self.statechglogger.recordchgevent(myid, event)
                            self.statechglogger.recordfilechange(inittab, 
                                                                 tmpfile, myid)
                            os.rename(tmpfile, inittab)
                            resetsecon(inittab)
                        else:
                            initText += "\nid:3:initdefault:\n"
                            writeFile(tmpfile, initText, self.logger)
                            self.iditerator += 1
                            myid = iterate(self.iditerator, self.rulenumber)
                            event = {"eventtype": "conf", "filepath": inittab}
                            self.statechglogger.recordchgevent(myid, event)
                            self.statechglogger.recordfilechange(inittab, 
                                                                 tmpfile, myid)
                            os.rename(tmpfile, inittab)
                            resetsecon(inittab)
                    else:
                        results += inittab + " not found, no other init " + \
                                   "system found. If you are using a " + \
                                   "supported Linux OS, please report " + \
                                   "this as a bug\n"

            if self.ci3.getcurrvalue():
                # Due to automatic removal of dependent packages, the full
                # removal of X and related packages cannot be undone
                if re.search("opensuse", self.myos):
                    cmd = ["zypper", "-n", "rm", "-u", "xorg-x11*", "kde*",
                           "xinit*"]
                    self.ch.executeCommand(cmd)
                elif re.search("debian|ubuntu", self.myos):
                    cmd = ["apt-get", "purge", "-y", "--force-yes", "unity.*",
                           "xserver.*", "gnome.*", "x11.*", "lightdm.*",
                           "libx11.*", "libqt.*"]
                    self.ch.executeCommand(cmd)
                    cmd2 = ["apt-get", "autoremove", "-y"]
                    self.ch.executeCommand(cmd2)
                elif re.search("fedora", self.myos):
                    # Fedora does not use the same group packages as other
                    # RHEL-based OSs. Removing this package will remove the X
                    # Windows system, just less efficiently than using a group
                    self.ph.remove("xorg-x11-server-Xorg")
                    self.ph.remove("xorg-x11-xinit*")
                else:
                    cmd = ["yum", "groups", "mark", "convert"]
                    self.ch.executeCommand(cmd)
                    self.ph.remove("xorg-x11-xinit")
                    cmd2 = ["yum", "groupremove", "-y", "X Window System"]
                    if not self.ch.executeCommand(cmd2):
                        success = False
                        results += '"yum groupremove -y X Window System" ' + \
                                   'command failed\n'
            # Since LOCKDOWNX depends on having X installed, and REMOVEX
            # completely removes X from the system, LOCKDOWNX fix will only be
            # executed if REMOVEX is not.
            elif self.ci2.getcurrvalue():
                if self.sh.disableservice("xfs"):
                    self.iditerator += 1
                    myid = iterate(self.iditerator, self.rulenumber)
                    event = {"eventtype":   "servicehelper",
                             "servicename": "xfs",
                             "startstate":  "enabled",
                             "endstate":    "disabled"}
                    self.statechglogger.recordchgevent(myid, event)
                else:
                    success = False
                    results += "STONIX was unable to disable the xfs service\n"

                if not self.xservSecure:
                    serverrcString = "exec X :0 -nolisten tcp $@"
                    if not os.path.exists(self.serverrc):
                        createFile(self.serverrc, self.logger)
                        self.iditerator += 1
                        myid = iterate(self.iditerator, self.rulenumber)
                        event = {"eventtype": "creation",
                                 "filepath": self.serverrc}
                        self.statechglogger.recordchgevent(myid, event)
                        writeFile(self.serverrc, serverrcString, self.logger)
                    else:
                        open(self.serverrc, "a").write(serverrcString)

            self.rulesuccess = success
            if self.rulesuccess:
                self.detailedresults = "DisableGUILogon fix has been run " + \
                                       "to completion"
            else:
                self.detailedresults = "DisableGUILogon fix has been run " + \
                                       "but not to completion\n" + results
        except (KeyboardInterrupt, SystemExit):
            # User initiated exit
            raise
        except Exception:
            self.rulesuccess = False
            self.detailedresults += "\n" + traceback.format_exc()
            self.logdispatch.log(LogPriority.ERROR, self.detailedresults)
        self.formatDetailedResults("fix", self.rulesuccess,
                                   self.detailedresults)
        self.logdispatch.log(LogPriority.INFO, self.detailedresults)
        return self.rulesuccess
