#!/bin/bash
pyuic4 -o ui_dylan_main_listview.py dylan_main_listview.ui
